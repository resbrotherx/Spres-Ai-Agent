/** Markdown-lite parser: no HTML, no dependencies. Produces a tiny AST rendered with RN <Text>. */
export type MdInline = {
    type: 'text';
    text: string;
} | {
    type: 'code';
    text: string;
} | {
    type: 'bold';
    children: MdInline[];
} | {
    type: 'italic';
    children: MdInline[];
} | {
    type: 'link';
    href: string;
    children: MdInline[];
};
export interface MdListItem {
    inline: MdInline[];
    indent: number;
    index?: number;
}
export type MdBlock = {
    type: 'paragraph';
    inline: MdInline[];
} | {
    type: 'heading';
    level: number;
    inline: MdInline[];
} | {
    type: 'code';
    lang: string;
    code: string;
} | {
    type: 'list';
    ordered: boolean;
    items: MdListItem[];
} | {
    type: 'quote';
    inline: MdInline[];
} | {
    type: 'table';
    header: MdInline[][];
    rows: MdInline[][][];
} | {
    type: 'hr';
};
/** Only http(s) and mailto links are clickable. */
export declare function safeHref(href: string): string | null;
export declare function parseInline(src: string): MdInline[];
export declare function parseMarkdown(text: string): MdBlock[];
