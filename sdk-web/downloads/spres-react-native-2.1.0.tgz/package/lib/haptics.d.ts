export type BrainboxHapticType = 'send' | 'receive' | 'error' | 'selection';
/** `true` = built-in tiny vibration (Android), `false` = off, or your own function (e.g. expo-haptics). */
export type BrainboxHaptics = boolean | ((type: BrainboxHapticType) => void);
/**
 * Fire a tiny haptic. The built-in fallback uses `Vibration` on Android only (needs the
 * android.permission.VIBRATE permission, which Expo includes by default). iOS ignores
 * vibration durations and always buzzes ~400ms, so it stays silent there unless you pass a
 * function, e.g. `haptics={(t) => Haptics.selectionAsync()}` with expo-haptics.
 */
export declare function triggerHaptic(haptics: BrainboxHaptics | undefined, type: BrainboxHapticType): void;
