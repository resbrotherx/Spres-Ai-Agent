/** A parsed Server-Sent Event. */
export interface SSEEvent {
    event: string;
    data: string;
    id?: string;
}
/**
 * Incremental Server-Sent Events parser (https://html.spec.whatwg.org/#event-stream-interpretation).
 * Feed it arbitrary text chunks; it returns the complete events contained so far and keeps any
 * partial line/event for the next call. Handles \n, \r\n and \r line endings, comments (`: ping`),
 * multi-line `data:` and a missing space after the colon.
 */
export declare class SSEParser {
    private buffer;
    private eventName;
    private dataLines;
    private lastId;
    private sawData;
    push(chunk: string): SSEEvent[];
    /** Flush at end of stream: a final event without a trailing blank line is dispatched. */
    end(): SSEEvent[];
    private line;
    private dispatch;
}
