/** Anything with `setString` (RN core / @react-native-clipboard) or `setStringAsync` (expo-clipboard). */
export interface BrainboxClipboard {
    setString?: (text: string) => void;
    setStringAsync?: (text: string) => Promise<unknown>;
}
/**
 * Resolve a clipboard: the one passed in, else React Native's core `Clipboard` when this RN version
 * still ships it (checked via the property descriptor so the deprecation getter only runs on copy).
 * Returns null when none is available — the copy button is then hidden.
 */
export declare function resolveClipboard(custom?: BrainboxClipboard | null): BrainboxClipboard | null;
export declare function copyText(clip: BrainboxClipboard | null, text: string): Promise<boolean>;
