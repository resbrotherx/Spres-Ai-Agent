import type { BrainboxChatResponse, BrainboxClientOptions, BrainboxFeedbackPayload, BrainboxHealth, BrainboxSession, BrainboxSessionDetail, BrainboxSessionsGrouped, BrainboxStreamHandle, BrainboxStreamHandlers, BrainboxUploadFile, BrainboxUploadResponse, BrainboxUser } from './types';
export interface RequestOptions {
    body?: unknown;
    query?: Record<string, string | undefined | null>;
    form?: FormData;
    signal?: AbortSignal;
    timeout?: number;
}
/**
 * Headless Brainbox API client for React Native (and Node 18+). No dependencies: uses `fetch`
 * for normal requests and `XMLHttpRequest` + `onprogress` for streaming, which works in React
 * Native without polyfills.
 */
export declare class BrainboxClient {
    readonly apiUrl: string;
    readonly tenantId?: string;
    user: BrainboxUser;
    private credential;
    private extraHeaders;
    private timeout;
    private fetchImpl?;
    private XHR?;
    /** Use POST /api/chat/stream when available. */
    streaming: boolean;
    /** Set after the server answered 404/405 for /api/chat/stream; later calls go straight to /api/chat. */
    streamUnsupported: boolean;
    constructor(options: BrainboxClientOptions);
    private get apiKey();
    private headers;
    /** `{tenant_id?, user_id?, user_name?}` — only fields that are set, so a proxy can inject them. */
    private scope;
    private url;
    /** Low-level request helper. Resolves with parsed JSON; rejects with BrainboxError. */
    request<T = any>(method: string, path: string, opts?: RequestOptions): Promise<T>;
    private chatBody;
    /** POST /api/chat — the whole answer at once. */
    chat(question: string, sessionId?: string | null, opts?: {
        signal?: AbortSignal;
    }): Promise<BrainboxChatResponse>;
    /**
     * Stream an answer from POST /api/chat/stream (SSE over XMLHttpRequest). Falls back to POST /api/chat
     * when streaming is disabled, unsupported by the server (404/405), or fails before the first event.
     * Callbacks never fire after `abort()`.
     */
    streamChat(question: string, handlers?: BrainboxStreamHandlers): BrainboxStreamHandle;
    /** POST /api/chat/session — create an empty conversation. */
    createSession(title?: string): Promise<BrainboxSession>;
    /** POST /api/chat/sessions — conversations grouped by date. */
    listSessions(): Promise<BrainboxSessionsGrouped>;
    /** GET /api/chat/session/{id}/messages */
    getSessionMessages(sessionId: string): Promise<BrainboxSessionDetail>;
    /**
     * Upload a local file (`{uri, name, type}` from any picker). Images go to /api/chat/upload/image,
     * everything else to /api/chat/upload/file. Pass `kind` to force one.
     */
    uploadFile(file: BrainboxUploadFile, sessionId?: string | null, opts?: {
        kind?: 'file' | 'image';
    }): Promise<BrainboxUploadResponse>;
    uploadImage(file: BrainboxUploadFile, sessionId?: string | null): Promise<BrainboxUploadResponse>;
    /** POST /api/chat/feedback — 👍/👎 on an answer. A 👎 is reported to staff as a knowledge gap. */
    sendFeedback(payload: BrainboxFeedbackPayload): Promise<{
        ok: boolean;
    }>;
    /** GET /api/health (no key needed). */
    health(): Promise<BrainboxHealth>;
}
