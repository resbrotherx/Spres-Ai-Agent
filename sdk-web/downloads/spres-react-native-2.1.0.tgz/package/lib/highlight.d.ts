/**
 * Sublime Text–style (Monokai) syntax colouring for chat code blocks — a tiny dependency-free
 * tokenizer: comments, strings, numbers, keywords, literals, calls and types.
 */
export type CodeTokenKind = 'com' | 'str' | 'num' | 'kw' | 'lit' | 'fn' | 'type';
export type CodeToken = [CodeTokenKind | null, string];
/** Split source into coloured tokens. `#` starts a comment except in C-like languages. */
export declare function highlightTokens(src: string, lang?: string): CodeToken[];
/** Monokai colours used by the code block (always a dark editor, in light and dark mode). */
export declare const SUBLIME: {
    readonly bg: "#272822";
    readonly head: "#1e1f1c";
    readonly line: "#141512";
    readonly text: "#f8f8f2";
    readonly gutter: "#75715e";
    readonly label: "#a59f85";
    readonly copy: "#cfcfc2";
    readonly dots: readonly ["#ff5f57", "#febc2e", "#28c840"];
    readonly com: "#75715e";
    readonly str: "#e6db74";
    readonly num: "#ae81ff";
    readonly lit: "#ae81ff";
    readonly kw: "#f92672";
    readonly fn: "#a6e22e";
    readonly type: "#66d9ef";
};
/** Tokens grouped per source line. */
export declare function highlightLines(src: string, lang?: string): CodeToken[][];
