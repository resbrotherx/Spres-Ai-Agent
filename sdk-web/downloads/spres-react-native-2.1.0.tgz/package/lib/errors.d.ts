export type BrainboxErrorCode = 'network' | 'timeout' | 'aborted' | 'auth' | 'forbidden' | 'not_found' | 'validation' | 'rate_limited' | 'server' | 'stream' | `http_${number}`;
/**
 * Every client method rejects with a BrainboxError. `message` is safe to show to end users;
 * `detail` holds the raw backend `detail` for logging.
 */
export declare class BrainboxError extends Error {
    status: number;
    code: BrainboxErrorCode;
    detail?: unknown;
    /** True when trying again later may succeed (network, timeout, 429, 5xx). */
    retryable: boolean;
    constructor(message: string, opts?: {
        status?: number;
        code?: BrainboxErrorCode;
        detail?: unknown;
        retryable?: boolean;
    });
}
/** Turn a FastAPI `detail` (string | [{loc,msg}] | object) into one readable line. */
export declare function formatDetail(detail: unknown): string | null;
/** Build a friendly error from an HTTP status and the parsed JSON body (if any). */
export declare function httpError(status: number, body: unknown): BrainboxError;
export declare function networkError(cause?: unknown): BrainboxError;
export declare function timeoutError(): BrainboxError;
export declare function abortError(): BrainboxError;
