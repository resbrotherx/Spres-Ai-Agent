/**
 * v1 compatibility layer: `BrainboxReactNativeSDK` and `ChatScreen` keep working on top of the v2
 * client. The old `/api/chat/stream` call (which 404'd) now streams when the server supports it and
 * otherwise falls back to POST /api/chat.
 */
import React from 'react';
import { StyleProp, TextStyle, ViewStyle } from 'react-native';
import { BrainboxClient } from './client';
import type { BrainboxChatResponse } from './types';
/** @deprecated Use `BrainboxClient` (headless) or the `BrainboxChat` / `BrainboxWidget` components. */
export declare class BrainboxReactNativeSDK {
    readonly client: BrainboxClient;
    constructor(apiUrl: string, apiKey: string, tenantId?: string);
    /** Training needs a secret key — only call this from internal tools, never ship a secret key in an app. */
    ingest(sourceType: string, content: string, filePath?: string, metadata?: Record<string, any>): Promise<any>;
    chat(question: string, sessionId?: string): Promise<BrainboxChatResponse>;
    /** v1 signature. `onChunk` receives text deltas; `onComplete` the final response object. */
    streamChat(question: string, sessionId: string | undefined, onChunk: (chunk: string) => void, onComplete?: (result: any) => void, onError?: (error: Error) => void): Promise<void>;
    createChatSession(title?: string): Promise<any>;
    listSessions(): Promise<import("./types").BrainboxSessionsGrouped>;
    getSessionMessages(sessionId: string): Promise<import("./types").BrainboxSessionDetail>;
    healthCheck(): Promise<any>;
}
export interface ChatScreenProps {
    sdk: BrainboxReactNativeSDK;
    title?: string;
    placeholder?: string;
    primaryColor?: string;
    /** Ignored in v2 (the bot bubble follows the design system). */
    accentColor?: string;
    style?: StyleProp<ViewStyle>;
    /** Ignored in v2. */
    headerStyle?: StyleProp<ViewStyle>;
    /** Ignored in v2. */
    inputStyle?: StyleProp<TextStyle>;
    /** Ignored in v2 (the send button is an icon). */
    buttonText?: string;
}
/** @deprecated v1 component — renders the v2 `BrainboxChat`. */
export declare function ChatScreen({ sdk, title, placeholder, primaryColor, style }: ChatScreenProps): React.JSX.Element;
