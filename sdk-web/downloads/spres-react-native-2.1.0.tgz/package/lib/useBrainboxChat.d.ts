import type { BrainboxClient } from './client';
import { BrainboxError } from './errors';
import type { BrainboxChatResponse, BrainboxRating, BrainboxSearchResult, BrainboxSessionsGrouped, BrainboxStorage, BrainboxUploadFile } from './types';
export type BrainboxMessageStatus = 'sending' | 'streaming' | 'done' | 'error' | 'stopped';
export interface BrainboxMessage {
    /** Local id (stable for React keys). */
    id: string;
    role: 'user' | 'assistant';
    text: string;
    /** ISO timestamp. */
    createdAt: string;
    status: BrainboxMessageStatus;
    /** Server message id (assistant messages; used for feedback). */
    messageId?: number | string | null;
    searchResults?: BrainboxSearchResult[] | null;
    reasoning?: string | null;
    feedback?: BrainboxRating | null;
    cached?: boolean;
    /** Loaded from history (not animated in). */
    fromHistory?: boolean;
}
export type BrainboxChatEventName = 'message' | 'response' | 'error' | 'session' | 'feedback' | 'upload' | 'fallback' | 'open' | 'close';
export interface UseBrainboxChatOptions {
    /** Stream answers token by token (default true). Falls back to whole answers automatically. */
    streaming?: boolean;
    /** Where the last session id is stored. Default: AsyncStorage if installed, else memory. `null` disables. */
    storage?: BrainboxStorage | null;
    /** Storage namespace (default 'bb-rn'); combined with tenant and user id. */
    storageKey?: string;
    /** Restore the last conversation on mount (default true). */
    persistSession?: boolean;
    /** Open this conversation on mount instead of the stored one. */
    initialSessionId?: string;
    /** Receives every event: message, response, error, session, feedback, upload, fallback. */
    onEvent?: (name: BrainboxChatEventName, detail: any) => void;
}
export interface UseBrainboxChatResult {
    messages: BrainboxMessage[];
    /** Text of the answer currently streaming ('' when idle). */
    streamingText: string;
    /** A request is in flight. */
    sending: boolean;
    /** Tokens are arriving (sending && at least one token received). */
    streaming: boolean;
    error: BrainboxError | null;
    /** The last question failed and `retry()` can resend it. */
    canRetry: boolean;
    sessionId: string | null;
    sessions: BrainboxSessionsGrouped | null;
    sessionsLoading: boolean;
    /** Loading a past conversation. */
    historyLoading: boolean;
    /** Initial restore from storage finished. */
    ready: boolean;
    send: (text: string) => Promise<BrainboxChatResponse | null>;
    stop: () => void;
    retry: () => Promise<BrainboxChatResponse | null>;
    newChat: () => void;
    loadSession: (sessionId: string) => Promise<void>;
    refreshSessions: () => Promise<BrainboxSessionsGrouped | null>;
    sendFeedback: (localMessageId: string, rating: BrainboxRating) => Promise<void>;
    uploadFile: (file: BrainboxUploadFile) => Promise<void>;
    clearError: () => void;
}
/** Backend timestamps without a timezone are UTC. */
export declare function parseServerTime(s?: string | null): Date;
export declare function useBrainboxChat(client: BrainboxClient, options?: UseBrainboxChatOptions): UseBrainboxChatResult;
