import React, { ReactNode } from 'react';
import { StyleProp, ViewStyle } from 'react-native';
import { BrainboxThemeOptions } from '../theme';
export type BrainboxPosition = 'bottom-right' | 'bottom-left';
/** 'auto' (default): round icon until a `text` is set, then a pill. 'button': pill with icon + label. 'icon': round button. */
export type BrainboxLauncherVariant = 'auto' | 'button' | 'icon';
export interface BrainboxLauncherProps {
    onPress: () => void;
    /** Unread replies; shows a red badge when > 0. */
    unread?: number;
    position?: BrainboxPosition;
    /** Distance from the screen corner (default {x: 20, y: 28}). */
    offset?: {
        x?: number;
        y?: number;
    };
    /** Diameter of the round launcher (default 60). The pill is 46pt tall. */
    size?: number;
    /** 'auto' (default), 'button' (pill) or 'icon' (round). */
    variant?: BrainboxLauncherVariant;
    /** Launcher label. Empty (default) = icon-only launcher. */
    text?: string;
    theme?: BrainboxThemeOptions;
    accessibilityLabel?: string;
    /** Hide with a scale-out (e.g. while the chat is open). */
    hidden?: boolean;
    style?: StyleProp<ViewStyle>;
}
/** Floating omago launcher: a round blue gradient button with a chat icon (or a pill once a text is set), unread badge. No shadow. */
export declare function BrainboxLauncher({ onPress, unread, position, offset, size, variant, text, theme, accessibilityLabel, hidden, style }: BrainboxLauncherProps): React.JSX.Element;
export interface BrainboxModalProps {
    visible: boolean;
    onClose: () => void;
    position?: BrainboxPosition;
    theme?: BrainboxThemeOptions;
    /** Receives `{floating}`: true on wide screens (window), false on phones (full-screen sheet). */
    children: (layout: {
        floating: boolean;
    }) => ReactNode;
}
/**
 * Presents the chat with a slide-up spring. Phones (< 576pt wide): full-screen frosted sheet with a 22pt
 * top radius. Tablets: a 380×600 floating omago window (radius 22, 2pt frosted border, no shadow).
 */
export declare function BrainboxModal({ visible, onClose, position, theme, children }: BrainboxModalProps): React.JSX.Element;
