import React from 'react';
import type { BrainboxChatResponse } from '../types';
import { BrainboxChatProps } from './BrainboxChat';
import { BrainboxLauncherVariant, BrainboxPosition } from './BrainboxLauncher';
export interface BrainboxWidgetProps extends Omit<BrainboxChatProps, 'onClose' | 'safeArea'> {
    position?: BrainboxPosition;
    /** Launcher distance from the corner (default {x: 20, y: 28}). */
    offset?: {
        x?: number;
        y?: number;
    };
    /** Open on first render. */
    defaultOpen?: boolean;
    /** Controlled open state (use with onOpenChange). */
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    /** Show the floating launcher (default true). Set false to open from your own button via the ref. */
    launcher?: boolean;
    launcherLabel?: string;
    /** 'auto' (default): round icon until `launcherText` is set, then a pill. 'button': pill. 'icon': round button. */
    launcherVariant?: BrainboxLauncherVariant;
    /** Text on the 'button' launcher (default 'Chat'). */
    launcherText?: string;
}
export interface BrainboxWidgetHandle {
    open: () => void;
    close: () => void;
    toggle: () => void;
    isOpen: () => boolean;
    send: (text: string) => Promise<BrainboxChatResponse | null>;
    newChat: () => void;
}
/**
 * Drop-in floating assistant: launcher + slide-up chat sheet. Render it once near the root of your
 * app (it overlays the screen and lets touches through outside the launcher).
 */
export declare const BrainboxWidget: React.ForwardRefExoticComponent<BrainboxWidgetProps & React.RefAttributes<BrainboxWidgetHandle>>;
