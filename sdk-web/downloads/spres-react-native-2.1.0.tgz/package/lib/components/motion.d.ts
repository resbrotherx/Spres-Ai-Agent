import React, { ReactNode } from 'react';
/** Apple-like sheet easing from the design spec. */
export declare const EASE_SHEET: import("react-native").EasingFunction;
/** True when the OS "Reduce motion" setting is on. */
export declare function useReducedMotion(): boolean;
/** Message appear: 220ms translateY 6px + fade (opacity only when motion is reduced). */
export declare function Appear({ children, enabled, reduced }: {
    children: ReactNode;
    enabled: boolean;
    reduced: boolean;
}): React.JSX.Element;
/** Three 6px dots with a staggered 1.2s pulse. */
export declare function TypingDots({ color, reduced }: {
    color: string;
    reduced: boolean;
}): React.JSX.Element;
/** Soft blinking caret ▍ appended to streaming text (state-driven so it works as a nested <Text>). */
export declare function Caret({ color }: {
    color: string;
}): React.JSX.Element;
