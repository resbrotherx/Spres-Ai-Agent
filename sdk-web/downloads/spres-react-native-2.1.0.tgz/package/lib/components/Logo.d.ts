import React from 'react';
import { StyleProp, ViewStyle } from 'react-native';
export interface BrainboxOrbColors {
    core?: string;
    mid?: string;
    rim?: string;
}
export interface BrainboxLogoProps {
    size?: number;
    style?: StyleProp<ViewStyle>;
    /** Show a custom image instead of the Brainbox mark. */
    logoUrl?: string;
    /** 'orb' (default): the omago blue orb. 'cube': the classic Brainbox cube mark. */
    variant?: 'orb' | 'cube';
    /** Override the orb gradient stops (default #9dbcff -> #2f6bff -> #1d3fae). */
    colors?: BrainboxOrbColors;
}
/**
 * The omago orb: a radial blue gradient (#9dbcff -> #2f6bff -> #1d3fae, soft rim), a white highlight
 * and the white speaker glyph, on a 64×64 viewBox.
 */
export declare function BrainboxOrb({ size, colors }: {
    size?: number;
    colors?: BrainboxOrbColors;
}): React.JSX.Element;
/** The Brainbox logo: the blue orb by default (or the classic cube, or your own image). */
export declare function BrainboxLogo({ size, style, logoUrl, variant, colors }: BrainboxLogoProps): React.JSX.Element;
/**
 * Accent gradient fill (radial, light at the top-left) that stretches to its parent. Used behind the
 * launcher pill and the send button. Place it first inside a view with `overflow: 'hidden'`.
 */
export declare function BrainboxGradientFill({ light, mid, deep, cx, cy }: {
    light: string;
    mid: string;
    deep: string;
    cx?: string;
    cy?: string;
}): React.JSX.Element;
/** Lavender body background: a vertical gradient with a soft glow on the right (omago body). */
export declare function BrainboxPanelBackground({ from, to, glow }: {
    from: string;
    to: string;
    glow: string;
}): React.JSX.Element;
/** Round launcher mark: the orb-style accent circle with a white chat glyph. */
export declare function BrainboxLauncherMark({ size, from, to }: {
    size?: number;
    from?: string;
    to?: string;
}): React.JSX.Element;
