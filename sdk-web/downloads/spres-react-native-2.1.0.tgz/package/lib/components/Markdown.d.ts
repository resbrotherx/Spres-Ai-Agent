import React, { ReactNode } from 'react';
import type { BrainboxTokens } from '../theme';
import { BrainboxClipboard } from '../clipboard';
export interface MarkdownProps {
    text: string;
    tokens: BrainboxTokens;
    /** Text colour (bubble foreground). */
    color: string;
    linkColor: string;
    /** Rendered inline at the end of the last paragraph/list item (e.g. the streaming caret). */
    trailing?: ReactNode;
    clipboard?: BrainboxClipboard | null;
    /** On a coloured (user) bubble: inline code uses a translucent white fill. */
    inverted?: boolean;
}
/** Safe markdown-lite renderer: bold, italic, inline code, code blocks, lists, headings, quotes, tables, links. */
export declare function Markdown(p: MarkdownProps): React.JSX.Element;
