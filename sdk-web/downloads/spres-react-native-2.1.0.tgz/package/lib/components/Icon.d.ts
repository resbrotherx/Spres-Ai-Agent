import React from 'react';
export type BrainboxIconName = 'newChat' | 'history' | 'close' | 'arrowUp' | 'stop' | 'copy' | 'check' | 'thumbsUp' | 'thumbsDown' | 'chevronDown' | 'chevronRight' | 'sparkles' | 'alert' | 'refresh' | 'message' | 'file' | 'search' | 'paperclip' | 'send' | 'aichat';
export interface BrainboxIconProps {
    name: BrainboxIconName;
    size?: number;
    color: string;
    strokeWidth?: number;
    /** Fill the shape (used for selected 👍/👎). */
    filled?: boolean;
}
/** SF-Symbols-like line icons (24 viewBox, stroke 1.75, round caps/joins). */
export declare function BrainboxIcon({ name, size, color, strokeWidth, filled }: BrainboxIconProps): React.JSX.Element;
