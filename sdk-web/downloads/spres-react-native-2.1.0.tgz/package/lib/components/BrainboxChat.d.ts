import React from 'react';
import { StyleProp, ViewStyle } from 'react-native';
import { BrainboxClient } from '../client';
import type { BrainboxStorage, BrainboxUser } from '../types';
import { BrainboxChatEventName, UseBrainboxChatResult } from '../useBrainboxChat';
import { BrainboxThemeOptions } from '../theme';
import { BrainboxHaptics } from '../haptics';
import { BrainboxClipboard } from '../clipboard';
import { BrainboxIconName } from './Icon';
export interface BrainboxBranding {
    /** Assistant name (default 'Brainbox AI'). Replaces {{botName}}. */
    botName?: string;
    /** Header title (defaults to botName). */
    title?: string;
    /** Header subtitle next to the green status dot (default 'Online'). */
    subtitle?: string;
    /** Custom image for the header and bot avatar instead of the blue orb. */
    logoUrl?: string;
    /** Welcome heading (default 'Hi {{name}}'). */
    greeting?: string;
}
export type BrainboxQuickAction = string | {
    title: string;
    description?: string;
    prompt?: string;
    icon?: BrainboxIconName;
};
export interface BrainboxFeatures {
    history?: boolean;
    newChat?: boolean;
    feedback?: boolean;
    copy?: boolean;
    sources?: boolean;
}
/** Connection props (same names as sdk-web / sdk-react). Pass `client` to reuse your own BrainboxClient. */
export interface BrainboxConnectionProps {
    apiUrl?: string;
    apiKey?: string;
    tenantId?: string;
    user?: BrainboxUser;
    headers?: Record<string, string>;
    timeout?: number;
    client?: BrainboxClient;
    /** Stream answers token by token (default true). Falls back to whole answers automatically. */
    streaming?: boolean;
    storage?: BrainboxStorage | null;
    storageKey?: string;
    persistSession?: boolean;
    initialSessionId?: string;
    onEvent?: (name: BrainboxChatEventName, detail: any) => void;
}
export interface BrainboxAppearanceProps {
    theme?: BrainboxThemeOptions;
    branding?: BrainboxBranding;
    /** Welcome text under the greeting. `{{name}}` / `{{botName}}` are replaced. */
    welcomeMessages?: string[];
    quickActions?: BrainboxQuickAction[];
    placeholder?: string;
    /** Tiny haptics on send/receive/error (default true). Pass a function to use expo-haptics etc. */
    haptics?: BrainboxHaptics;
    features?: BrainboxFeatures;
    /** Clipboard for the copy buttons (e.g. expo-clipboard). Default: RN core Clipboard if present; `null` hides copy. */
    clipboard?: BrainboxClipboard | null;
    /** Shows the black close circle in the header. */
    onClose?: () => void;
    /** Shows the paperclip button in the composer and calls this when tapped (wire it to your file picker). */
    onAttach?: () => void;
    /** Wrap in SafeAreaView (default true). */
    safeArea?: boolean;
    keyboardVerticalOffset?: number;
    style?: StyleProp<ViewStyle>;
}
export type BrainboxChatProps = BrainboxConnectionProps & BrainboxAppearanceProps;
export interface BrainboxChatViewProps extends BrainboxAppearanceProps {
    /** Controller from `useBrainboxChat`. */
    chat: UseBrainboxChatResult;
    user?: BrainboxUser;
}
/** Build (and memoise) a BrainboxClient from props, or use `props.client`. */
export declare function useClientFromProps(p: BrainboxConnectionProps): BrainboxClient;
/** Wrap onEvent with haptics. */
export declare function useHapticEvents(haptics: BrainboxHaptics | undefined, onEvent?: BrainboxConnectionProps['onEvent']): (name: BrainboxChatEventName, detail: any) => void;
/** The omago chat UI driven by a `useBrainboxChat` controller. */
export declare function BrainboxChatView(props: BrainboxChatViewProps): React.JSX.Element;
/** Full-screen Brainbox chat (omago design): header, history, streaming answers, feedback, composer. */
export declare function BrainboxChat(props: BrainboxChatProps): React.JSX.Element;
