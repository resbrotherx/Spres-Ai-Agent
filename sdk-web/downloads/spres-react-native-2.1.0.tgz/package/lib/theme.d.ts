export type BrainboxThemeMode = 'light' | 'dark' | 'auto';
export interface BrainboxThemeOptions {
    /** Brand colour (default blue #2563eb): user bubbles, send button, launcher, pills, links. */
    primary?: string;
    /** 'light' (default, lavender glass), 'dark' (deep aubergine) or 'auto' (follows the device setting). */
    mode?: BrainboxThemeMode;
    /** Optional font family override. Default: the system font (SF Pro on iOS, Roboto on Android). */
    fontFamily?: string;
}
export interface BrainboxTokens {
    dark: boolean;
    /** Window / panel colour (omago lavender #f3f6fd). */
    panel: string;
    /** Body gradient (top -> bottom) drawn behind the transcript. */
    bodyFrom: string;
    bodyTo: string;
    /** Soft glow on the body gradient. */
    bodyGlow: string;
    /** Translucent header over the panel and its bottom rule. */
    headerBg: string;
    headerBorder: string;
    /** 2px frosted window border. */
    frameBorder: string;
    bg: string;
    surface: string;
    surface2: string;
    fill: string;
    fillStrong: string;
    label: string;
    secondary: string;
    tertiary: string;
    quaternary: string;
    separator: string;
    separatorStrong: string;
    accent: string;
    accentPressed: string;
    accentTint: string;
    /** Light / deep ends of the accent gradient (send button, launcher). */
    accentLight: string;
    accentDeep: string;
    onAccent: string;
    botBubble: string;
    botText: string;
    /** Quick-action / history pill. */
    pillBg: string;
    pillBorder: string;
    pillText: string;
    /** Composer card and its tool buttons. */
    composerBg: string;
    composerBorder: string;
    toolBg: string;
    /** Header close circle. */
    closeBg: string;
    closeIcon: string;
    /** Purple orb logo stops (centre -> mid -> rim). */
    orbCore: string;
    orbMid: string;
    orbRim: string;
    success: string;
    successText: string;
    successTint: string;
    danger: string;
    dangerText: string;
    dangerTint: string;
    warning: string;
    gradientFrom: string;
    gradientTo: string;
    backdrop: string;
    fontFamily?: string;
    mono: string;
}
/** Parse #rgb/#rrggbb/rgb()/rgba() into [r,g,b] (null if unknown, e.g. named colours). */
export declare function parseColor(c?: string): [number, number, number] | null;
export declare function withAlpha(c: string, a: number): string;
export declare function buildTokens(options: BrainboxThemeOptions | undefined, systemDark: boolean): BrainboxTokens;
/** Resolve theme tokens, following the device appearance when mode is 'auto'. */
export declare function useBrainboxTheme(options?: BrainboxThemeOptions): BrainboxTokens;
/** Type scale (system font). The omago header, author line and pills use heavy weights. */
export declare function typo(t: BrainboxTokens): {
    caption2: {
        fontSize: number;
        lineHeight: number;
        fontWeight: "400";
        fontFamily: string;
    } | {
        fontSize: number;
        lineHeight: number;
        fontWeight: "400";
        fontFamily?: undefined;
    };
    caption: {
        fontSize: number;
        lineHeight: number;
        fontWeight: "400";
        fontFamily: string;
    } | {
        fontSize: number;
        lineHeight: number;
        fontWeight: "400";
        fontFamily?: undefined;
    };
    footnote: {
        fontSize: number;
        lineHeight: number;
        fontWeight: "400";
        fontFamily: string;
    } | {
        fontSize: number;
        lineHeight: number;
        fontWeight: "400";
        fontFamily?: undefined;
    };
    footnoteMedium: {
        fontSize: number;
        lineHeight: number;
        fontWeight: "500";
        fontFamily: string;
    } | {
        fontSize: number;
        lineHeight: number;
        fontWeight: "500";
        fontFamily?: undefined;
    };
    body: {
        fontSize: number;
        lineHeight: number;
        fontWeight: "400";
        fontFamily: string;
    } | {
        fontSize: number;
        lineHeight: number;
        fontWeight: "400";
        fontFamily?: undefined;
    };
    bodyStrong: {
        fontSize: number;
        lineHeight: number;
        fontWeight: "600";
        fontFamily: string;
    } | {
        fontSize: number;
        lineHeight: number;
        fontWeight: "600";
        fontFamily?: undefined;
    };
    headline: {
        fontSize: number;
        lineHeight: number;
        fontWeight: "600";
        letterSpacing: number;
        fontFamily: string;
    } | {
        fontSize: number;
        lineHeight: number;
        fontWeight: "600";
        letterSpacing: number;
        fontFamily?: undefined;
    };
    title3: {
        fontSize: number;
        lineHeight: number;
        fontWeight: "800";
        letterSpacing: number;
        fontFamily: string;
    } | {
        fontSize: number;
        lineHeight: number;
        fontWeight: "800";
        letterSpacing: number;
        fontFamily?: undefined;
    };
    /** Header title: bold 17. */
    title: {
        fontSize: number;
        lineHeight: number;
        fontWeight: "800";
        fontFamily: string;
    } | {
        fontSize: number;
        lineHeight: number;
        fontWeight: "800";
        fontFamily?: undefined;
    };
    /** Header subtitle: 11pt. */
    subtitle: {
        fontSize: number;
        lineHeight: number;
        fontWeight: "600";
        fontFamily: string;
    } | {
        fontSize: number;
        lineHeight: number;
        fontWeight: "600";
        fontFamily?: undefined;
    };
    /** Message author line (name + time). */
    meta: {
        fontSize: number;
        lineHeight: number;
        fontWeight: "800";
        fontFamily: string;
    } | {
        fontSize: number;
        lineHeight: number;
        fontWeight: "800";
        fontFamily?: undefined;
    };
    metaTime: {
        fontSize: number;
        lineHeight: number;
        fontWeight: "700";
        fontFamily: string;
    } | {
        fontSize: number;
        lineHeight: number;
        fontWeight: "700";
        fontFamily?: undefined;
    };
    /** Quick-action / history pill. */
    pill: {
        fontSize: number;
        lineHeight: number;
        fontWeight: "700";
        fontFamily: string;
    } | {
        fontSize: number;
        lineHeight: number;
        fontWeight: "700";
        fontFamily?: undefined;
    };
};
