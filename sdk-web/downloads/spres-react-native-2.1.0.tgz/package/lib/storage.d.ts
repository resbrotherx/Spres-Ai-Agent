import type { BrainboxStorage } from './types';
/** In-memory storage used when AsyncStorage is not installed (state lasts for the app session). */
export declare function createMemoryStorage(): BrainboxStorage;
/**
 * `@react-native-async-storage/async-storage` when installed (optional peer dependency), else an
 * in-memory store. The literal require inside try/catch is Metro's optional-dependency pattern
 * (enabled by default in Expo and @react-native/metro-config). If your bundler refuses it, pass a
 * `storage` prop explicitly instead.
 */
export declare function getDefaultStorage(): BrainboxStorage;
