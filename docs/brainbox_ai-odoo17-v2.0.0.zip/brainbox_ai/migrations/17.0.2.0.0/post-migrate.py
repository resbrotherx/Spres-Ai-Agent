# -*- coding: utf-8 -*-
"""2.0: the chat UI moved to the Brainbox web SDK and conversations live in the Brainbox backend.

Odoo removes the ir.model / ir.model.fields entries of code that disappeared, but keeps the
orphan table of the former ``brainbox.ai.session`` model: drop it here. The former
``res.users.brainbox_display_mode`` column is dropped by Odoo itself.
"""
import logging

_logger = logging.getLogger(__name__)


def migrate(cr, version):
    cr.execute("SELECT to_regclass('brainbox_ai_session')")
    if cr.fetchone()[0]:
        cr.execute('DROP TABLE brainbox_ai_session CASCADE')
        _logger.info('Brainbox AI: dropped the obsolete brainbox_ai_session table')
