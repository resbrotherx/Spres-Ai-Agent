/** @odoo-module **/
/**
 * Thin glue between Odoo and the official Brainbox web SDK (window.Brainbox).
 *
 * The SDK renders the whole chat UI. This service only:
 *   - loads the non-secret settings from /brainbox_ai/config,
 *   - maps them to Brainbox.init() options (apiUrl = the Odoo proxy, no API key),
 *   - owns the global instance (floating / sidebar / systray modes),
 *   - lets the AI Assistant page and the brainbox_chat view widget create their own instances.
 */

import { reactive } from "@odoo/owl";
import { browser } from "@web/core/browser/browser";
import { _t } from "@web/core/l10n/translation";
import { registry } from "@web/core/registry";
import { session } from "@web/session";

const HEX = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/;
const PROXY_URL = "/brainbox_ai/proxy";
// Colours that mean "use the SDK default" and are therefore not passed to Brainbox.init():
// the omago defaults (#b93fff / #fbf1ff, the add-on's setting defaults and the SDK 2.2 defaults)
// and the defaults the add-on briefly shipped with SDK 2.1 (#0071E3 / #FFFFFF), so databases that
// saved those fall back to the restored design. Any other colour an admin picked is passed through.
const DEFAULT_PRIMARIES = ["#b93fff", "#0071e3"];
const DEFAULT_PANELS = ["#fbf1ff", "#ffffff", "#fff"];

function customColor(value, sdkDefaults) {
    const v = (value || "").trim();
    return HEX.test(v) && !sdkDefaults.includes(v.toLowerCase()) ? v : undefined;
}
// Below Odoo dropdown menus (1000), popovers, dialogs (1050+) and notifications, above page content.
const Z_INDEX = 990;

let sdkPromise = null;

/**
 * Resolve the SDK: the bundled copy (loaded before this file by the asset bundle) or,
 * when "SDK script URL" is set, that script loaded dynamically.
 */
function loadSdk(url) {
    if (sdkPromise) {
        return sdkPromise;
    }
    const bundled = window.Brainbox;
    if (!url) {
        sdkPromise = bundled
            ? Promise.resolve(adaptSdk(bundled))
            : Promise.reject(new Error("Brainbox web SDK is not loaded."));
        return sdkPromise;
    }
    sdkPromise = resolveSdk(url, bundled).then(adaptSdk);
    return sdkPromise;
}

function resolveSdk(url, bundled) {
    return new Promise((resolve, reject) => {
        const script = document.createElement("script");
        script.src = url;
        script.async = true;
        script.dataset.brainboxSdk = "1";
        script.onload = () => {
            if (window.Brainbox && typeof window.Brainbox.init === "function") {
                resolve(window.Brainbox);
            } else if (bundled) {
                window.Brainbox = bundled;
                console.warn("[Brainbox AI] The SDK script URL did not define window.Brainbox; using the bundled SDK.");
                resolve(bundled);
            } else {
                reject(new Error("The SDK script did not define window.Brainbox."));
            }
        };
        script.onerror = () => {
            if (bundled) {
                console.warn("[Brainbox AI] Could not load the SDK script URL; using the bundled SDK.");
                resolve(bundled);
            } else {
                reject(new Error("Could not load the Brainbox web SDK."));
            }
        };
        document.head.appendChild(script);
    });
}

// The SDK sends `context` as "Context:\n<ctx>\n\nQuestion:\n<question>" and the backend stores it like
// that. Strip the prefix when a past conversation is loaded so users only see their own question.
const CONTEXT_PREFIX = /^Context:\n[\s\S]*?\n\nQuestion:\n/;

/**
 * Patch the SDK's public Client class once (no change to the SDK file): conversations restored from
 * history show the user's question without the context prefix.
 */
function adaptSdk(Brainbox) {
    const proto = Brainbox && Brainbox.Client && Brainbox.Client.prototype;
    if (!proto || typeof proto.getSessionMessages !== "function" || proto.__odooContextStrip) {
        return Brainbox;
    }
    const original = proto.getSessionMessages;
    proto.getSessionMessages = async function (...args) {
        const data = await original.apply(this, args);
        if (data && Array.isArray(data.messages)) {
            for (const message of data.messages) {
                if (message && message.role === "user" && typeof message.content === "string") {
                    message.content = message.content.replace(CONTEXT_PREFIX, "");
                }
            }
        }
        return data;
    };
    proto.__odooContextStrip = true;
    return Brainbox;
}

function navbarHeight() {
    const navbar = document.querySelector(".o_main_navbar");
    const height = navbar ? navbar.getBoundingClientRect().height : 0;
    return height > 0 ? Math.round(height) : 46;
}

export const brainboxService = {
    dependencies: ["rpc", "notification", "action"],
    start(env, { rpc, notification, action }) {
        const db = session.db || "";
        const uid = session.uid || (session.user_context && session.user_context.uid);
        const state = reactive({
            ready: false,
            config: null,
            open: false, // global instance open
            mode: null, // current mode of the global instance ('floating' | 'sidebar')
            pageActive: 0,
        });
        let instance = null;
        let reopenAfterPage = false;

        const configPromise = rpc("/brainbox_ai/config", {}, { silent: true })
            .then((config) => {
                state.config = config;
                return config;
            })
            .catch(() => {
                state.config = { allowed: false };
                return state.config;
            })
            .finally(() => {
                state.ready = true;
            });

        /** Settings -> Brainbox.init() options shared by every instance. */
        function baseOptions(config, extra = {}) {
            const cfg = config || {};
            const options = {
                apiUrl: PROXY_URL,
                // no apiKey / tenantId: the Odoo proxy adds the secret key and the user identity
                headers: { "X-Brainbox-Proxy": "1" },
                credentials: "same-origin",
                // the id only namespaces localStorage; the proxy overrides user_id server-side
                user: { id: uid ? String(uid) : undefined, name: cfg.user_name || session.name || "" },
                position: cfg.position === "bottom-left" ? "bottom-left" : "bottom-right",
                theme: {
                    primary: customColor(cfg.primary_color, DEFAULT_PRIMARIES),
                    panel: customColor(cfg.panel_color, DEFAULT_PANELS),
                },
                branding: {
                    botName: cfg.bot_name || undefined,
                    title: cfg.company_name || undefined,
                    subtitle: cfg.subtitle || "",
                    logoUrl: cfg.logo_url || null,
                },
                launcher: { text: cfg.launcher_text || "Chat" },
                zIndex: Z_INDEX,
                storageKey: `bb-odoo:${db}`,
            };
            if (Array.isArray(cfg.welcome_messages) && cfg.welcome_messages.length) {
                options.welcomeMessages = cfg.welcome_messages;
            }
            if (Array.isArray(cfg.quick_actions)) {
                options.quickActions = cfg.quick_actions;
            }
            return Object.assign(options, extra);
        }

        function usable(config) {
            return !!(config && config.allowed && config.configured);
        }

        /** Global instance for the floating / sidebar / systray display modes. */
        async function startGlobal() {
            const config = await configPromise;
            if (!usable(config) || config.display_mode === "disabled" || instance) {
                return;
            }
            let Brainbox;
            try {
                Brainbox = await loadSdk(config.sdk_script_url);
            } catch (e) {
                console.warn(`[Brainbox AI] ${e.message}`);
                return;
            }
            const companyMode = config.display_mode;
            const switchable = companyMode === "floating" || companyMode === "sidebar";
            const options = baseOptions(config, {
                mode: companyMode === "sidebar" ? "sidebar" : "floating",
                sidebarTop: navbarHeight(),
                sidebarPushContent: ".o_action_manager",
                onEvent: (name, detail) => {
                    if (name === "open" || name === "close") {
                        state.open = name === "open";
                    } else if (name === "modechange") {
                        state.mode = detail.mode;
                    }
                },
            });
            if (switchable) {
                // users can dock / undock; the SDK remembers the choice in localStorage
                options.allowedModes = ["floating", "sidebar"];
            } else {
                // systray mode: floating window opened from the systray icon only
                options.allowedModes = ["floating"];
                options.launcher = { ...options.launcher, type: "none" };
            }
            instance = Brainbox.init(options);
            state.mode = instance.getMode();
            state.open = instance.isOpen();
            if (state.pageActive) {
                hideForPage();
            }
        }

        function hideForPage() {
            document.body.classList.add("bb-odoo-page-active");
            if (instance && instance.isOpen()) {
                reopenAfterPage = true;
                instance.close();
            }
        }

        function openSettings() {
            action.doAction("brainbox_ai.action_brainbox_ai_config_settings");
        }

        function notifyNotConfigured() {
            const config = state.config || {};
            if (!config.is_admin) {
                return;
            }
            const close = notification.add(
                _t("Set the Backend URL and the secret API key (or Tenant ID) to enable the assistant."),
                {
                    title: _t("Brainbox AI is not configured"),
                    type: "warning",
                    buttons: [
                        {
                            name: _t("Open settings"),
                            primary: true,
                            onClick: () => {
                                close();
                                openSettings();
                            },
                        },
                    ],
                }
            );
        }

        const service = {
            state,
            get instance() {
                return instance;
            },
            configPromise,
            loadSdk: () => configPromise.then((config) => loadSdk(config && config.sdk_script_url)),
            baseOptions: (extra) => baseOptions(state.config, extra),
            usable: () => usable(state.config),
            openSettings,
            toggle() {
                if (!state.ready) {
                    return;
                }
                if (!usable(state.config)) {
                    notifyNotConfigured();
                    return;
                }
                if (instance) {
                    instance.toggle();
                }
            },
            /** Called by the AI Assistant page: hide the global launcher/window while it is shown. */
            enterPage() {
                state.pageActive++;
                hideForPage();
            },
            leavePage() {
                state.pageActive = Math.max(0, state.pageActive - 1);
                if (state.pageActive) {
                    return;
                }
                document.body.classList.remove("bb-odoo-page-active");
                if (instance && reopenAfterPage) {
                    instance.open();
                }
                reopenAfterPage = false;
            },
        };

        if (uid) {
            // wait for the web client so the navbar can be measured for the sidebar offset
            let started = false;
            const start = () => {
                if (!started) {
                    started = true;
                    startGlobal();
                }
            };
            env.bus.addEventListener("WEB_CLIENT_READY", start, { once: true });
            browser.setTimeout(start, 4000); // safety net
        }
        return service;
    },
};

registry.category("services").add("brainbox_ai", brainboxService);
