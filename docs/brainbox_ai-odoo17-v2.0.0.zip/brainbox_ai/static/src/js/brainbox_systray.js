/** @odoo-module **/

import { Component, useState } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

/** Sparkle icon in the top bar that opens / closes the global SDK instance. */
export class BrainboxSystray extends Component {
    static template = "brainbox_ai.Systray";
    static props = {};

    setup() {
        this.bb = useService("brainbox_ai");
        this.state = useState(this.bb.state);
    }

    get visible() {
        const cfg = this.state.config;
        if (!this.state.ready || !cfg || !cfg.allowed || this.state.pageActive || cfg.display_mode === "disabled") {
            return false;
        }
        if (!cfg.configured) {
            return !!cfg.is_admin; // admins get a hint with a link to the settings
        }
        const mode = cfg.display_mode;
        return (
            mode === "sidebar" ||
            mode === "systray" ||
            this.state.mode === "sidebar" ||
            (mode === "floating" && cfg.systray_in_floating)
        );
    }

    get label() {
        return this.state.open ? "Close AI assistant" : "Open AI assistant";
    }

    toggle() {
        this.bb.toggle();
    }
}

registry.category("systray").add("brainbox_ai.Systray", { Component: BrainboxSystray }, { sequence: 30 });
