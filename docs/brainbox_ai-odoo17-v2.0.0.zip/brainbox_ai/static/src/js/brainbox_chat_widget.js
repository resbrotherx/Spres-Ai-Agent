/** @odoo-module **/

import { Component, onWillUnmount, useEffect, useRef, useState } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { session } from "@web/session";
import { standardWidgetProps } from "@web/views/widgets/standard_widget_props";

const modelNames = new Map();

/**
 * Inline chat for one specific place of a view:
 *
 *     <widget name="brainbox_chat"/>
 *     <widget name="brainbox_chat" height="600" title="Ask AI" record_context="0"/>
 */
export class BrainboxChatWidget extends Component {
    static template = "brainbox_ai.ChatWidget";
    static props = {
        ...standardWidgetProps,
        height: { type: Number, optional: true },
        title: { type: String, optional: true },
        recordContext: { type: Boolean, optional: true },
    };

    setup() {
        this.bb = useService("brainbox_ai");
        this.orm = useService("orm");
        this.state = useState(this.bb.state);
        this.containerRef = useRef("container");
        this.widget = null;

        useEffect(
            (resModel, resId, ready) => {
                if (ready) {
                    this.mount(resModel, resId);
                }
                return () => this.unmount();
            },
            () => [this.props.record.resModel, this.props.record.resId, this.state.ready]
        );
        onWillUnmount(() => this.unmount());
    }

    get config() {
        return this.state.config || {};
    }
    get height() {
        return this.props.height && this.props.height >= 240 ? this.props.height : 520;
    }

    async modelName(model) {
        if (!modelNames.has(model)) {
            modelNames.set(
                model,
                this.orm
                    .searchRead("ir.model", [["model", "=", model]], ["name"], { limit: 1 })
                    .then((rows) => (rows.length ? rows[0].name : model))
                    .catch(() => model)
            );
        }
        return modelNames.get(model);
    }

    async mount(resModel, resId) {
        const token = (this.token = {});
        if (!this.bb.usable()) {
            return;
        }
        let Brainbox;
        try {
            Brainbox = await this.bb.loadSdk();
        } catch (e) {
            console.warn(`[Brainbox AI] ${e.message}`);
            return;
        }
        if (token !== this.token || !this.containerRef.el) {
            return;
        }
        const record = this.props.record;
        const options = {
            mode: "inline",
            container: this.containerRef.el,
            allowedModes: ["inline"],
            storageKey: `bb-odoo:${session.db || ""}:rec:${resModel}:${resId || "new"}`,
        };
        if (this.props.recordContext !== false) {
            options.context = async () => {
                if (!record.resId) {
                    return null;
                }
                const name = record.data.display_name || record.data.name || "";
                const label = await this.modelName(record.resModel);
                return `Odoo record: ${label} — ${name} (id ${record.resId})`;
            };
        }
        const extra = this.bb.baseOptions(options);
        if (this.props.title) {
            extra.branding = { ...extra.branding, title: this.props.title };
        }
        this.widget = Brainbox.init(extra);
    }

    unmount() {
        this.token = null;
        if (this.widget) {
            this.widget.destroy();
            this.widget = null;
        }
    }

    openSettings() {
        this.bb.openSettings();
    }
}

export const brainboxChatWidget = {
    component: BrainboxChatWidget,
    extractProps: ({ attrs }) => ({
        height: attrs.height ? parseInt(attrs.height, 10) || undefined : undefined,
        title: attrs.title,
        recordContext: !["0", "false", "False"].includes(attrs.record_context),
    }),
};

registry.category("view_widgets").add("brainbox_chat", brainboxChatWidget);
