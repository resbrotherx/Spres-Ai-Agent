/** @odoo-module **/

import { Component, onMounted, onWillUnmount, useRef, useState } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { session } from "@web/session";

/** "AI Assistant" app: the SDK in page mode (conversation list + chat) inside the action. */
export class BrainboxChatPage extends Component {
    static template = "brainbox_ai.ChatPage";
    static props = ["*"];

    setup() {
        this.bb = useService("brainbox_ai");
        this.state = useState(this.bb.state);
        this.containerRef = useRef("container");
        this.widget = null;
        this.alive = true;

        onMounted(async () => {
            this.bb.enterPage();
            await this.bb.configPromise;
            if (!this.alive || !this.bb.usable()) {
                return;
            }
            try {
                const Brainbox = await this.bb.loadSdk();
                if (!this.alive || !this.containerRef.el) {
                    return;
                }
                this.widget = Brainbox.init(
                    this.bb.baseOptions({
                        mode: "page",
                        container: this.containerRef.el,
                        allowedModes: ["page"],
                        storageKey: `bb-odoo:${session.db || ""}:page`,
                    })
                );
            } catch (e) {
                console.warn(`[Brainbox AI] ${e.message}`);
            }
        });
        onWillUnmount(() => {
            this.alive = false;
            if (this.widget) {
                this.widget.destroy();
                this.widget = null;
            }
            this.bb.leavePage();
        });
    }

    get config() {
        return this.state.config || {};
    }

    openSettings() {
        this.bb.openSettings();
    }
}

registry.category("actions").add("brainbox_ai.chat_page", BrainboxChatPage);
