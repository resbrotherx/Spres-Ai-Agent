# -*- coding: utf-8 -*-
{
    'name': 'Brainbox AI',
    'version': '17.0.2.0.0',
    'category': 'Productivity',
    'summary': 'Brainbox AI assistant in every Odoo app, powered by the official Brainbox web SDK',
    'description': """
Brainbox AI for Odoo
====================

A thin integration of the official Brainbox web SDK (``spres-web``): the SDK
renders the chat, the Brainbox backend does the AI work, and Odoo only adds
settings, permissions and a same-origin proxy that injects the secret API key
and the logged-in user's identity and role.

* Floating launcher in every app (default), docked sidebar, systray-only or disabled
* A full-screen "AI Assistant" app with chat history
* ``<widget name="brainbox_chat"/>`` to embed the chat in one specific view
""",
    'author': 'Brainbox',
    'license': 'LGPL-3',
    'application': True,
    'installable': True,
    'depends': ['base', 'web', 'base_setup'],
    'external_dependencies': {'python': ['requests']},
    'data': [
        'views/res_config_settings_views.xml',
        'views/brainbox_ai_menus.xml',
    ],
    'assets': {
        'web.assets_backend': [
            # the official SDK first (defines window.Brainbox), then the Odoo glue
            'brainbox_ai/static/lib/brainbox-web-sdk/brainbox-web-sdk.js',
            'brainbox_ai/static/src/scss/brainbox_ai.scss',
            'brainbox_ai/static/src/js/*.js',
            'brainbox_ai/static/src/xml/*.xml',
        ],
    },
    'images': ['static/description/icon.png'],
}
