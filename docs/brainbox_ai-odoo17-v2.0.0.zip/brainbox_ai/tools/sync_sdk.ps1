<#
.SYNOPSIS
    Update the bundled Brainbox web SDK (static/lib/brainbox-web-sdk/brainbox-web-sdk.js).

.DESCRIPTION
    Copies brainbox-web-sdk.js from a local checkout of the SDK repository (sdk-web), or downloads
    it from the npm package "spres-web" through the jsDelivr CDN. Afterwards upgrade the module
    (odoo-bin -u brainbox_ai) or just reload the browser in dev mode so the asset bundle is rebuilt.

.EXAMPLE
    .\tools\sync_sdk.ps1 -SdkPath C:\src\ai\sdk-web
.EXAMPLE
    .\tools\sync_sdk.ps1 -Version 2.0.0
#>
param(
    [string]$SdkPath = "",
    [string]$Version = "2"
)

$ErrorActionPreference = "Stop"
$target = Join-Path $PSScriptRoot "..\static\lib\brainbox-web-sdk\brainbox-web-sdk.js"
New-Item -ItemType Directory -Force (Split-Path $target) | Out-Null

if ($SdkPath) {
    $source = Join-Path $SdkPath "brainbox-web-sdk.js"
    if (-not (Test-Path $source)) { throw "Not found: $source" }
    Copy-Item $source $target -Force
    Write-Host "Copied $source"
} else {
    $url = "https://cdn.jsdelivr.net/npm/spres-web@$Version/brainbox-web-sdk.js"
    Invoke-WebRequest -Uri $url -OutFile $target -UseBasicParsing
    Write-Host "Downloaded $url"
}

$header = Get-Content $target -TotalCount 3 | Select-String "Brainbox Web SDK v"
Write-Host "Bundled SDK: $header"
