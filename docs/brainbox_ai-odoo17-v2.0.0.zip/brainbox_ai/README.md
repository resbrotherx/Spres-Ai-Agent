# Brainbox AI for Odoo 17

`brainbox_ai` is a thin Odoo add-on around the official **Brainbox web SDK** (`spres-web`, the
`ai/sdk-web` repository). The same SDK is used on plain HTML sites, WordPress and any JavaScript
app; this module only installs it in the Odoo backend and makes it configurable from **Settings**.

* The **SDK** renders the whole chat UI (launcher, window, sidebar, full page, history, uploads,
  markdown, error banners).
* The **Brainbox backend** does all the AI work and stores the conversations.
* **Odoo** stores the settings, decides who may use the assistant and with which role, and
  forwards the SDK's requests with the secret API key added on the server.

There are no Odoo models for chats or messages.

```
 Browser (Odoo web client)
   brainbox-web-sdk.js  ──  Brainbox.init({ apiUrl: '/brainbox_ai/proxy', headers: {'X-Brainbox-Proxy': '1'} })
        │  same-origin fetch with the Odoo session cookie, no API key
        ▼
 Odoo  /brainbox_ai/proxy/api/...           (controllers/proxy.py, forwarding only)
        │  1. requires the X-Brainbox-Proxy header and a logged-in, allowed user
        │  2. allows only the chat endpoints (whitelist)
        │  3. adds  Authorization: Bearer <secret key>
        │  4. overrides tenant_id, user_id = "odoo:<db>:<uid>", user_name, user_role
        ▼
 Brainbox backend  /api/chat, /api/chat/sessions, ...   (does the AI work)
```

Display options (all from **Settings › Brainbox AI**):

* **Floating launcher** in the bottom corner of every app (default)
* **Docked sidebar** on the right of every app, opened from a sparkle icon in the top bar
* **Systray only**: the sparkle icon opens the chat window
* **Disabled**: only the AI Assistant app and embedded widgets
* **AI Assistant app**: a full-screen page with the conversation list
* **Embeddable widget**: `<widget name="brainbox_chat"/>` in one specific view

---

## 1. Install

1. Put the `brainbox_ai` folder in an addons directory (here `custom_addons`) that is listed in
   `addons_path` in `odoo.conf`.
2. Dependencies: `base`, `web`, `base_setup` and the Python package `requests` (shipped with Odoo).
3. Install from **Apps** › *Update Apps List* › "Brainbox AI" › **Activate**, or from the command line.

## 2. Run Odoo

From the Odoo source folder (Windows paths shown):

```bash
.venv\Scripts\python.exe odoo-bin -c odoo.conf                                     # http://localhost:8069
.venv\Scripts\python.exe odoo-bin -c odoo.conf -d <db> -i brainbox_ai --stop-after-init   # install
.venv\Scripts\python.exe odoo-bin -c odoo.conf -d <db> -u brainbox_ai --stop-after-init   # upgrade
```

If a server already runs on 8069, add `--http-port 8075` (or another free port) to the one-shot
commands. Restart the running server (or use `?debug=assets`) after updating the module so the
browser gets the new asset bundle.

Upgrading from 1.x removes the old `brainbox.ai.session` model and its table and the
`res.users.brainbox_display_mode` field. Conversations stay in the Brainbox backend.

## 3. Configure

**Settings › Brainbox AI** (also **AI Assistant › Configuration**, administrators only):

| Setting | Meaning |
|---|---|
| Backend URL | Brainbox API base URL without `/api`, e.g. `https://brainbox.example.com`. |
| Tenant ID | Your organisation in Brainbox. Optional with a secret key (the key's tenant is used). |
| Secret API key (sk_...) | Stored in `ir.config_parameter`, never sent to browsers, never shown again. Leave empty to keep the stored key; tick *Remove it on save* to delete it. |
| SDK script URL | Optional. Load `brainbox-web-sdk.js` from a CDN or your Brainbox server instead of the bundled copy (e.g. `https://cdn.jsdelivr.net/npm/spres-web@2`). If it fails to load, the bundled copy is used. |
| Test connection | Calls `/api/health` from the Odoo server. |
| Display mode / Position | See section 4. |
| Systray icon in floating mode | Also show the sparkle icon in the top bar in floating mode. |
| Allowed groups | Only users in these groups get the assistant and may use the proxy. Empty = internal users. Administrators always have access. |
| Role mapping, Vendor groups, Customer groups | See section 6. |
| Colors, names, logo, welcome message, quick actions | Passed to the SDK as `theme`, `branding`, `launcher.text`, `welcomeMessages` and `quickActions`. In the welcome message `{{name}}` is the user's first name and `{{botName}}` the bot name. |

The browser receives only non-secret settings, from `/brainbox_ai/config`.

Use a **secret** key (`sk_...`). Publishable keys (`pk_...`) are meant for public websites: Brainbox
treats every request made with them as `public` and ignores the `user_role` sent by Odoo.

## 4. Display modes

| Mode | What users see |
|---|---|
| Floating (default) | The SDK launcher in a bottom corner of every app. The dock button in the chat header moves it to the sidebar and back. |
| Sidebar | A panel on the right, under the Odoo navbar. Opening it pushes the app content to the left (on screens of 992px and wider) so nothing is hidden. The sparkle icon in the top bar opens and closes it. Users can pop it out to a floating window. |
| Systray | Only the sparkle icon in the top bar; it opens the floating chat window. |
| Disabled | Nothing global. The AI Assistant app and embedded widgets still work. |

Each user's floating/sidebar choice, open state and last conversation are remembered in the
browser (`localStorage`, key `bb-odoo:<db>:...`) by the SDK itself; nothing is stored in Odoo.

While the **AI Assistant** app is open, the global launcher or sidebar is hidden, and an open
sidebar or window comes back when you leave the app.

If the module is not configured yet, administrators see the sparkle icon; clicking it shows a
notification with a link to the settings. Other users see nothing.

## 5. Embed the chat in one view

The `brainbox_chat` view widget renders the SDK inline (`mode: 'inline'`). By default the current
record is sent as context with each question (`Odoo record: Contact — Acme Corporation (id 10)`),
and each record keeps its own conversation.

```xml
<record id="view_partner_form_brainbox" model="ir.ui.view">
    <field name="name">res.partner.form.brainbox</field>
    <field name="model">res.partner</field>
    <field name="inherit_id" ref="base.view_partner_form"/>
    <field name="arch" type="xml">
        <xpath expr="//sheet" position="inside">
            <widget name="brainbox_chat" height="520" title="Ask about this contact"/>
        </xpath>
    </field>
</record>
```

Put this in your own module (with `brainbox_ai` in its `depends`), or create the view from
*Settings › Technical › Views* in developer mode.

| Attribute | Default | Meaning |
|---|---|---|
| `height` | `520` | Height in px (minimum 240). |
| `title` | header title from Settings | Title shown in the chat header. |
| `record_context` | `1` | `0` sends questions without the record context. |

## 6. Permissions and user roles

Every proxied request carries the identity of the logged-in Odoo user. The proxy removes any
`tenant_id`, `user_id`, `user_name` and `user_role` sent by the browser and sets:

* `tenant_id`: the Tenant ID setting (when set),
* `user_id`: `odoo:<database>:<user id>`, so every user only sees their own conversations,
* `user_name`: the user's name,
* `user_role`: from the role mapping below. Brainbox uses it to decide which knowledge the user may read.

Role precedence, first match wins:

1. Administrators (`base.group_system`) → `admin`
2. Users in a **Vendor group** → `vendor`
3. Users in a **Customer group** → `customer`
4. Internal users (`base.group_user`) → **Role of internal users**: `internal` (default) or `public`
5. Portal users (`base.group_portal`) → **Role of portal users**: `customer` (default), `portal`, `vendor` or `public`
6. Anyone else → `public`

Public (not logged-in) visitors never reach the proxy (`auth='user'`).

### What the proxy allows

| Path under `/brainbox_ai/proxy/` | Methods | Timeout |
|---|---|---|
| `api/chat` | POST | 200 s |
| `api/chat/sessions` | POST, GET | 30 s |
| `api/chat/session` | POST | 30 s |
| `api/chat/session/<id>/messages` | GET | 30 s |
| `api/chat/upload/file`, `api/chat/upload/image` | POST (multipart, max 10 MB) | 60 s |
| `api/health` | GET | 30 s |

Everything else returns 404, including `api/train`, `api/ingest` and `api/admin`: training and
key management are not available from the browser. Every request also needs the
`X-Brainbox-Proxy: 1` header. A cross-site form cannot send a custom header, so the header protects
this `csrf=False` route against cross-site request forgery. Users outside the allowed groups get
403.

The backend's status code and JSON body are returned unchanged, so the SDK shows its own messages.
If the backend cannot be reached, the proxy answers 502 (or 504 on a timeout) with
`{"detail": "Cannot reach the Brainbox AI server..."}`, and the SDK shows its error banner with Retry.

## 7. Updating the bundled SDK

The SDK is bundled at `static/lib/brainbox-web-sdk/brainbox-web-sdk.js` and loaded before the Odoo
glue in `web.assets_backend`. Do not edit it here: change the SDK repository, then copy it in:

```powershell
# from a checkout of the SDK repository
.\tools\sync_sdk.ps1 -SdkPath C:\Users\USER\Documents\PERSONAL\ai\sdk-web
# or from the npm package spres-web (through jsDelivr)
.\tools\sync_sdk.ps1 -Version 2
```

Then upgrade the module (`-u brainbox_ai`) or restart Odoo. You can also leave the bundled copy as
it is and set **SDK script URL** to use a CDN or your own server.

## 8. The same SDK outside Odoo

On any other website, load the same file and use a **publishable** key directly (it can only ask
questions, as `public`), or put a small proxy like this one in front of it:

```html
<script src="https://cdn.jsdelivr.net/npm/spres-web@2"></script>
<script>
  Brainbox.init({ apiUrl: 'https://brainbox.example.com', apiKey: 'pk_...', branding: { botName: 'Acme Assistant' } });
</script>
```

React/Next.js apps use `sdk-react` and mobile apps use `sdk-react-native`. They talk to the same backend.

## 9. Module layout

```
brainbox_ai/
├── __manifest__.py
├── controllers/
│   ├── main.py          /brainbox_ai/config (non-secret settings), /brainbox_ai/logo
│   └── proxy.py         /brainbox_ai/proxy/<path> (whitelisted forwarding + identity injection)
├── models/
│   ├── brainbox_backend.py      settings helpers, allowed users, role mapping, health check
│   └── res_config_settings.py   Settings › Brainbox AI (stored in ir.config_parameter)
├── migrations/17.0.2.0.0/post-migrate.py   drops the 1.x session table
├── static/lib/brainbox-web-sdk/brainbox-web-sdk.js   official SDK (vendored, unmodified)
├── static/src/js/
│   ├── brainbox_service.js      loads config, maps settings → Brainbox.init(), global instance
│   ├── brainbox_systray.js      sparkle icon in the top bar
│   ├── brainbox_chat_page.js    AI Assistant client action (SDK page mode)
│   └── brainbox_chat_widget.js  <widget name="brainbox_chat"/> (SDK inline mode)
├── static/src/xml/brainbox_ai.xml, static/src/scss/brainbox_ai.scss
├── tools/sync_sdk.ps1
└── views/               settings form, AI Assistant menu
```

License: LGPL-3.
