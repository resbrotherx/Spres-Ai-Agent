# -*- coding: utf-8 -*-
import base64
import binascii

from odoo import api, fields, models, _
from odoo.exceptions import UserError

from .brainbox_backend import (
    DEFAULTS, DISPLAY_MODES, INTERNAL_ROLES, PARAM_PREFIX, PORTAL_ROLES, POSITIONS, BrainboxError,
)

GROUP_PARAMS = {
    'brainbox_allowed_group_ids': ('allowed_group_ids', 'base.group_user'),
    'brainbox_vendor_group_ids': ('vendor_group_ids', None),
    'brainbox_customer_group_ids': ('customer_group_ids', None),
}


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    # Connection
    brainbox_backend_url = fields.Char(
        'Backend URL', config_parameter='brainbox_ai.backend_url',
        help='Base URL of the Brainbox API, e.g. https://brainbox.example.com (without /api).')
    brainbox_api_key = fields.Char(
        'Secret API key (sk_...)',
        help='Sent by the Odoo server as "Authorization: Bearer <key>"; the key stays on the Odoo server and never '
             'reaches browsers. Use a secret key: publishable keys cannot assert user roles. '
             'Leave empty to keep the current key.')
    brainbox_api_key_set = fields.Boolean('API key is set')
    brainbox_api_key_clear = fields.Boolean('Remove stored API key')
    brainbox_tenant_id = fields.Char('Tenant ID', config_parameter='brainbox_ai.tenant_id')
    brainbox_sdk_script_url = fields.Char(
        'SDK script URL', config_parameter='brainbox_ai.sdk_script_url',
        help='Optional URL of brainbox-web-sdk.js (CDN or your Brainbox server). Empty = the copy bundled with this module.')

    # Display
    brainbox_display_mode = fields.Selection(
        DISPLAY_MODES, string='Display mode', default=DEFAULTS['display_mode'],
        config_parameter='brainbox_ai.display_mode')
    brainbox_position = fields.Selection(
        POSITIONS, string='Position', default=DEFAULTS['position'], config_parameter='brainbox_ai.position')
    brainbox_systray_in_floating = fields.Boolean(
        'Systray icon in floating mode', config_parameter='brainbox_ai.systray_in_floating')
    brainbox_allowed_group_ids = fields.Many2many(
        'res.groups', 'brainbox_ai_settings_group_rel', 'settings_id', 'group_id',
        string='Allowed groups', help='Only users in one of these groups see the assistant. Empty = all internal users.')

    # Roles sent to Brainbox (user_role decides which knowledge a user may read)
    brainbox_internal_role = fields.Selection(
        INTERNAL_ROLES, string='Role of internal users', default=DEFAULTS['internal_role'],
        config_parameter='brainbox_ai.internal_role')
    brainbox_portal_role = fields.Selection(
        PORTAL_ROLES, string='Role of portal users', default=DEFAULTS['portal_role'],
        config_parameter='brainbox_ai.portal_role')
    brainbox_vendor_group_ids = fields.Many2many(
        'res.groups', 'brainbox_ai_settings_vendor_group_rel', 'settings_id', 'group_id',
        string='Vendor groups', help='Users in these groups get the "vendor" role.')
    brainbox_customer_group_ids = fields.Many2many(
        'res.groups', 'brainbox_ai_settings_customer_group_rel', 'settings_id', 'group_id',
        string='Customer groups', help='Users in these groups get the "customer" role.')

    # Branding
    brainbox_primary_color = fields.Char(
        'Primary color', default=DEFAULTS['primary_color'], config_parameter='brainbox_ai.primary_color')
    brainbox_panel_color = fields.Char(
        'Panel color', default=DEFAULTS['panel_color'], config_parameter='brainbox_ai.panel_color')
    brainbox_bot_name = fields.Char('Bot name', default=DEFAULTS['bot_name'], config_parameter='brainbox_ai.bot_name')
    brainbox_company_name = fields.Char(
        'Header title', default=DEFAULTS['company_name'], config_parameter='brainbox_ai.company_name')
    brainbox_subtitle = fields.Char('Header subtitle', default=DEFAULTS['subtitle'], config_parameter='brainbox_ai.subtitle')
    brainbox_launcher_text = fields.Char(
        'Launcher text', default=DEFAULTS['launcher_text'], config_parameter='brainbox_ai.launcher_text')
    brainbox_logo = fields.Binary('Logo', attachment=False)
    brainbox_logo_url = fields.Char('Logo URL', config_parameter='brainbox_ai.logo_url')
    brainbox_welcome_message = fields.Text(
        'Welcome message', help='One intro bubble per line. {{name}} is replaced by the user name.')
    brainbox_quick_actions = fields.Text('Quick actions', help='One quick action per line. Clicking one sends it.')

    @api.model
    def get_values(self):
        res = super().get_values()
        icp = self.env['ir.config_parameter'].sudo()
        backend = self.env['brainbox.ai.backend']
        res.update({
            'brainbox_api_key': False,  # never sent back to the browser
            'brainbox_api_key_set': bool(icp.get_param(PARAM_PREFIX + 'api_key')),
            'brainbox_api_key_clear': False,
            'brainbox_welcome_message': backend._get_param('welcome_message'),
            'brainbox_quick_actions': backend._get_param('quick_actions'),
            'brainbox_logo': icp.get_param(PARAM_PREFIX + 'logo') or False,
        })
        for field_name, (key, default_xmlid) in GROUP_PARAMS.items():
            res[field_name] = [(6, 0, backend._group_ids_param(key, default_xmlid))]
        return res

    def set_values(self):
        super().set_values()
        if not self.env.user._is_system():
            return
        icp = self.env['ir.config_parameter'].sudo()
        settings = self.with_context(bin_size=False)
        if settings.brainbox_api_key_clear:
            icp.set_param(PARAM_PREFIX + 'api_key', False)
        elif (settings.brainbox_api_key or '').strip():
            icp.set_param(PARAM_PREFIX + 'api_key', settings.brainbox_api_key.strip())
        icp.set_param(PARAM_PREFIX + 'welcome_message', settings.brainbox_welcome_message or '')
        icp.set_param(PARAM_PREFIX + 'quick_actions', settings.brainbox_quick_actions or '')
        for field_name, (key, _default) in GROUP_PARAMS.items():
            icp.set_param(PARAM_PREFIX + key, ','.join(str(i) for i in settings[field_name].ids))
        logo = settings.brainbox_logo
        if isinstance(logo, bytes):
            logo = logo.decode()
        if logo:
            try:
                base64.b64decode(logo, validate=True)
            except (binascii.Error, ValueError):
                logo = None  # bin_size placeholder or garbage: keep the current logo
        if logo is not None:
            icp.set_param(PARAM_PREFIX + 'logo', logo or False)

    @api.constrains('brainbox_sdk_script_url')
    def _check_brainbox_sdk_script_url(self):
        for rec in self:
            url = (rec.brainbox_sdk_script_url or '').strip()
            if url and not (url.startswith('https://') or url.startswith('http://') or
                            (url.startswith('/') and not url.startswith('//'))):
                raise UserError(_('The SDK script URL must start with https://, http:// or / (got %s).', url))

    @api.constrains('brainbox_api_key', 'brainbox_tenant_id')
    def _check_brainbox_api_key(self):
        for rec in self:
            key = (rec.brainbox_api_key or '').strip()
            if not key:
                continue
            if key == (rec.brainbox_tenant_id or '').strip() or key.startswith('eyJ'):
                raise UserError(_(
                    'The API key field contains a Tenant ID, not a key. '
                    'Create a SECRET key in the Brainbox staff dashboard (Settings → API keys → Create key → Secret) '
                    'and paste that here — it starts with "sk_live_".'))
            if key.startswith('pk_'):
                raise UserError(_(
                    'This is a publishable (pk_…) key. Odoo needs a SECRET key (sk_live_…) so it can tell Brainbox '
                    "which role each Odoo user has. Create one in the staff dashboard under Settings → API keys."))

    @api.constrains('brainbox_primary_color', 'brainbox_panel_color')
    def _check_brainbox_colors(self):
        import re
        pattern = re.compile(r'^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$')
        for rec in self:
            for value in (rec.brainbox_primary_color, rec.brainbox_panel_color):
                if value and not pattern.match(value.strip()):
                    raise UserError(_('Colors must be hex values such as #b93fff (got %s).', value))

    def action_brainbox_test_connection(self):
        self.ensure_one()
        backend = self.env['brainbox.ai.backend']
        url = (self.brainbox_backend_url or '').strip()
        api_key = (self.brainbox_api_key or '').strip() or None
        if not api_key:
            # The form never shows the stored key; test with the saved one.
            api_key = (self.env['ir.config_parameter'].sudo().get_param('brainbox_ai.api_key') or '').strip() or None
        if api_key and (api_key.startswith('eyJ') or api_key == (self.brainbox_tenant_id or '').strip()):
            return self._brainbox_notify(
                _('Wrong value in API key'),
                _('The API key field holds the Tenant ID. Paste a secret key (sk_live_…) created in the '
                  'staff dashboard under Settings → API keys.'), 'danger')
        try:
            payload = backend.check_health(base_url=url, api_key=api_key)
        except BrainboxError as e:
            return self._brainbox_notify(_('Connection failed'), e.message, 'danger')
        status = payload.get('status') if isinstance(payload, dict) else None
        if status and status != 'healthy':
            return self._brainbox_notify(_('Server reachable'), _('The server reports status "%s".', status), 'warning')
        message = _('Brainbox AI server is reachable and healthy.')
        if not (self.brainbox_tenant_id or '').strip():
            message += ' ' + _('Remember to set a Tenant ID.')
        return self._brainbox_notify(_('Connection successful'), message, 'success')

    def _brainbox_notify(self, title, message, ntype):
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {'title': title, 'message': message, 'type': ntype, 'sticky': ntype == 'danger'},
        }
