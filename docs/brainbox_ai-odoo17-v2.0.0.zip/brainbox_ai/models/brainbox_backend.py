# -*- coding: utf-8 -*-
"""Settings helpers for the Brainbox AI integration.

This module holds no AI logic: the chat UI is the official Brainbox web SDK
(``static/lib/brainbox-web-sdk``) and the AI work is done by the Brainbox
backend. Odoo only stores the settings (``ir.config_parameter``), decides who
may use the assistant and with which role, and forwards the SDK's requests
(see ``controllers/proxy.py``) with the secret API key added server-side.
"""
import hashlib
import logging

import requests

from odoo import api, models, _

_logger = logging.getLogger(__name__)

PARAM_PREFIX = 'brainbox_ai.'

DISPLAY_MODES = [
    ('floating', 'Floating launcher (bottom corner of every app)'),
    ('sidebar', 'Docked sidebar (right side of every app)'),
    ('systray', 'Systray icon only'),
    ('disabled', 'Disabled (AI Assistant app and embedded widgets only)'),
]
POSITIONS = [('bottom-right', 'Bottom right'), ('bottom-left', 'Bottom left')]
INTERNAL_ROLES = [('internal', 'Internal'), ('public', 'Public')]
PORTAL_ROLES = [('customer', 'Customer'), ('portal', 'Portal'), ('vendor', 'Vendor'), ('public', 'Public')]

DEFAULTS = {
    'backend_url': '',
    'tenant_id': '',
    'sdk_script_url': '',
    'display_mode': 'floating',
    'position': 'bottom-right',
    'primary_color': '#0071E3',
    'panel_color': '#FFFFFF',
    'bot_name': 'Brainbox AI',
    'company_name': 'Brainbox AI',
    'subtitle': 'Your AI assistant, everywhere in Odoo',
    'logo_url': '',
    'launcher_text': 'Chat',
    'welcome_message': "Hi {{name}}! I'm {{botName}}. Ask me anything about your business.",
    'quick_actions': "What can you help me with?\nSummarize our latest activity\nHow do I get started?",
    'systray_in_floating': 'False',
    'internal_role': 'internal',
    'portal_role': 'customer',
}


class BrainboxError(Exception):
    """Error with a message that is safe to show to end users."""

    def __init__(self, message, code='error'):
        super().__init__(message)
        self.message = message
        self.code = code


class BrainboxBackend(models.AbstractModel):
    _name = 'brainbox.ai.backend'
    _description = 'Brainbox AI settings helper'

    # ------------------------------------------------------------------
    # Settings
    # ------------------------------------------------------------------
    @api.model
    def _get_param(self, key):
        value = self.env['ir.config_parameter'].sudo().get_param(PARAM_PREFIX + key)
        if value in (False, None):
            return DEFAULTS.get(key, '')
        return value

    @api.model
    def _backend_url(self):
        return (self._get_param('backend_url') or '').strip().rstrip('/')

    @api.model
    def _api_key(self):
        return (self.env['ir.config_parameter'].sudo().get_param(PARAM_PREFIX + 'api_key') or '').strip()

    @api.model
    def _tenant(self):
        return (self._get_param('tenant_id') or '').strip()

    @api.model
    def _is_configured(self):
        # A secret key implies its tenant, so the Tenant ID is only required without a key.
        return bool(self._backend_url() and (self._tenant() or self._api_key()))

    @api.model
    def _group_ids_param(self, key, default_xmlid=None):
        raw = self.env['ir.config_parameter'].sudo().get_param(PARAM_PREFIX + key)
        if raw is False and default_xmlid:
            group = self.env.ref(default_xmlid, raise_if_not_found=False)
            return group.ids if group else []
        ids = [int(x) for x in (raw or '').split(',') if x.strip().isdigit()]
        return self.env['res.groups'].sudo().browse(ids).exists().ids

    @api.model
    def _allowed_group_ids(self):
        ids = self._group_ids_param('allowed_group_ids', 'base.group_user')
        if not ids:
            group = self.env.ref('base.group_user', raise_if_not_found=False)
            ids = group.ids if group else []
        return ids

    @api.model
    def _is_user_allowed(self, user=None):
        user = user or self.env.user
        if not user or user._is_public():
            return False
        if user._is_system():
            return True
        return bool(set(self._allowed_group_ids()) & set(user.sudo().groups_id.ids))

    @api.model
    def _user_role(self, user=None):
        """Role sent to Brainbox as ``user_role`` (decides which knowledge the user may read).

        Precedence: admin > vendor groups > customer groups > internal > portal default.
        """
        user = (user or self.env.user).sudo()
        group_ids = set(user.groups_id.ids)
        if user._is_system():
            return 'admin'
        if group_ids & set(self._group_ids_param('vendor_group_ids')):
            return 'vendor'
        if group_ids & set(self._group_ids_param('customer_group_ids')):
            return 'customer'
        if user.has_group('base.group_user'):
            role = self._get_param('internal_role')
            return role if role in dict(INTERNAL_ROLES) else 'internal'
        if user.has_group('base.group_portal'):
            role = self._get_param('portal_role')
            return role if role in dict(PORTAL_ROLES) else 'customer'
        return 'public'

    @api.model
    def _company_display_mode(self):
        mode = self._get_param('display_mode')
        return mode if mode in dict(DISPLAY_MODES) else 'floating'

    @api.model
    def _logo_src(self):
        logo = self.env['ir.config_parameter'].sudo().get_param(PARAM_PREFIX + 'logo')
        if logo:
            return '/brainbox_ai/logo?v=%s' % hashlib.sha1(logo.encode()).hexdigest()[:10]
        return (self._get_param('logo_url') or '').strip()

    @api.model
    def _lines(self, key):
        return [line.strip() for line in (self._get_param(key) or '').splitlines() if line.strip()]

    @api.model
    def get_public_config(self):
        """Non-secret configuration sent to the browser (mapped to Brainbox.init() options)."""
        user = self.env.user
        allowed = self._is_user_allowed(user)
        config = {
            'allowed': allowed,
            'is_admin': user._is_system(),
            'user_name': user.name,
        }
        if not allowed:
            return config
        position = self._get_param('position')
        config.update({
            'configured': self._is_configured(),
            'display_mode': self._company_display_mode(),
            'sdk_script_url': (self._get_param('sdk_script_url') or '').strip(),
            'position': position if position in dict(POSITIONS) else 'bottom-right',
            'primary_color': self._get_param('primary_color') or DEFAULTS['primary_color'],
            'panel_color': self._get_param('panel_color') or DEFAULTS['panel_color'],
            'bot_name': self._get_param('bot_name') or DEFAULTS['bot_name'],
            'company_name': self._get_param('company_name') or DEFAULTS['company_name'],
            'subtitle': self._get_param('subtitle') or '',
            'logo_url': self._logo_src(),
            'launcher_text': self._get_param('launcher_text') or DEFAULTS['launcher_text'],
            'welcome_messages': self._lines('welcome_message'),
            'quick_actions': self._lines('quick_actions'),
            'systray_in_floating': self._get_param('systray_in_floating') in ('True', 'true', '1'),
        })
        return config

    # ------------------------------------------------------------------
    # Health check (Settings > Test connection)
    # ------------------------------------------------------------------
    @api.model
    def _extract_detail(self, response):
        try:
            payload = response.json()
        except ValueError:
            return (response.text or '').strip()[:300]
        detail = payload.get('detail') if isinstance(payload, dict) else None
        if isinstance(detail, list):
            return '; '.join(str(item.get('msg') if isinstance(item, dict) else item) for item in detail)[:300]
        return str(detail)[:300] if detail else ''

    @api.model
    def check_health(self, base_url=None, api_key=None):
        base_url = (base_url or self._backend_url() or '').strip().rstrip('/')
        if not base_url:
            raise BrainboxError(_('Please set the Backend URL first.'), 'not_configured')
        headers = {'Accept': 'application/json'}
        api_key = api_key or self._api_key()
        if api_key:
            headers['Authorization'] = 'Bearer %s' % api_key
        try:
            response = requests.get(base_url + '/api/health', headers=headers, timeout=10)
        except requests.exceptions.Timeout:
            raise BrainboxError(_('Connection timed out after 10 seconds.'), 'timeout')
        except requests.exceptions.RequestException:
            raise BrainboxError(_('Cannot reach %s. Check the URL and that the server is running.', base_url), 'unreachable')
        if response.status_code >= 400:
            detail = self._extract_detail(response)
            raise BrainboxError(_('Health check failed (HTTP %s)%s', response.status_code, (': ' + detail) if detail else ''),
                                'http_%s' % response.status_code)
        try:
            return response.json()
        except ValueError:
            raise BrainboxError(_('The server answered but did not return JSON. Is this the Brainbox API URL?'), 'invalid_response')
