# -*- coding: utf-8 -*-
"""Same-origin forwarding proxy for the Brainbox web SDK.

The SDK runs with ``apiUrl: '/brainbox_ai/proxy'`` and no API key. This
controller forwards a small whitelist of chat endpoints to the Brainbox
backend and adds, server-side:

* ``Authorization: Bearer <secret API key>`` (never sent to browsers),
* the identity of the logged-in Odoo user (``tenant_id``, ``user_id``,
  ``user_name``, ``user_role``), overriding anything the browser sent.

There is no AI logic here: the backend's status code and JSON body are
returned unchanged so the SDK renders its own messages and errors.

``api/chat/stream`` answers with Server-Sent Events: the upstream body is
relayed chunk by chunk as it arrives (no buffering), so tokens reach the
browser live. Errors returned before the stream starts (401/404/422 JSON)
are passed through like any other endpoint, which lets the SDK fall back to
``api/chat`` when the backend has no streaming endpoint yet.
"""
import json
import logging
import re

import requests

from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)

PROXY_HEADER = 'X-Brainbox-Proxy'
MAX_UPLOAD_SIZE = 10 * 1024 * 1024
MAX_JSON_BODY = 512 * 1024
IDENTITY_FIELDS = ('tenant_id', 'user_id', 'user_name', 'user_role')
SESSION_ID_RE = re.compile(r'^[A-Za-z0-9_.:-]{1,128}$')

TIMEOUT_CHAT = 200
TIMEOUT_DEFAULT = 30
TIMEOUT_UPLOAD = 60
# streaming: (connect, read) - the read timeout applies between chunks (the backend pings every 15 s)
TIMEOUT_STREAM = (10, 200)

# (subpath regex, allowed methods, body kind, timeout, multipart file field)
ROUTES = [
    (re.compile(r'api/chat'), {'POST'}, 'json', TIMEOUT_CHAT, None),
    (re.compile(r'api/chat/stream'), {'POST'}, 'stream', TIMEOUT_STREAM, None),
    (re.compile(r'api/chat/feedback'), {'POST'}, 'json', TIMEOUT_DEFAULT, None),
    (re.compile(r'api/chat/sessions'), {'POST', 'GET'}, 'json', TIMEOUT_DEFAULT, None),
    (re.compile(r'api/chat/session'), {'POST'}, 'json', TIMEOUT_DEFAULT, None),
    (re.compile(r'api/chat/session/[A-Za-z0-9_.:-]{1,128}/messages'), {'GET'}, 'json', TIMEOUT_DEFAULT, None),
    # chat history: rename / pin (update) and remove (delete); the proxy injects the Odoo user as owner
    (re.compile(r'api/chat/session/[A-Za-z0-9_.:-]{1,128}/(?:update|delete)'), {'POST'}, 'json', TIMEOUT_DEFAULT, None),
    (re.compile(r'api/chat/upload/file'), {'POST'}, 'multipart', TIMEOUT_UPLOAD, 'file'),
    (re.compile(r'api/chat/upload/image'), {'POST'}, 'multipart', TIMEOUT_UPLOAD, 'image'),
    (re.compile(r'api/health'), {'GET'}, 'none', TIMEOUT_DEFAULT, None),
]

UNREACHABLE = 'Cannot reach the Brainbox AI server. Please try again later or contact your administrator.'


def _json(status, payload):
    return request.make_response(
        json.dumps(payload),
        headers=[('Content-Type', 'application/json'), ('Cache-Control', 'no-store')],
        status=status,
    )


def _error(status, detail):
    return _json(status, {'detail': detail})


def _sse_response(upstream):
    """Relay an upstream text/event-stream body chunk by chunk, without buffering."""
    def generate():
        try:
            # chunk_size=None yields data as soon as it arrives from the socket
            for chunk in upstream.iter_content(chunk_size=None):
                if chunk:
                    yield chunk
        except requests.exceptions.RequestException as e:
            _logger.info('Brainbox AI proxy: stream interrupted (%s)', e.__class__.__name__)
            payload = json.dumps({'detail': 'The connection to the Brainbox AI server was interrupted.', 'status': 502})
            yield ('event: error\ndata: %s\n\n' % payload).encode()
        finally:
            upstream.close()

    response = request.make_response(
        generate(),
        headers=[
            ('Content-Type', 'text/event-stream; charset=utf-8'),
            ('Cache-Control', 'no-cache, no-store'),
            ('X-Accel-Buffering', 'no'),  # nginx in front of Odoo: do not buffer
        ],
        status=200,
    )
    response.direct_passthrough = True
    return response


class BrainboxProxyController(http.Controller):

    @http.route('/brainbox_ai/proxy/<path:subpath>', type='http', auth='user', csrf=False,
                methods=['GET', 'POST'], save_session=False)
    def proxy(self, subpath, **kw):
        httpreq = request.httprequest
        # A custom header cannot be sent cross-site without a CORS preflight, so
        # requiring it blocks cross-site form posts (this route has csrf=False).
        if httpreq.headers.get(PROXY_HEADER) != '1':
            return _error(403, 'Missing %s header.' % PROXY_HEADER)

        backend = request.env['brainbox.ai.backend']
        user = request.env.user
        if not backend._is_user_allowed(user):
            return _error(403, 'You are not allowed to use Brainbox AI. Ask your administrator for access.')

        route = next((r for r in ROUTES if r[0].fullmatch(subpath or '')), None)
        if not route:
            return _error(404, 'Not found.')
        _regex, methods, kind, timeout, file_field = route
        if httpreq.method not in methods:
            return _error(405, 'Method not allowed.')

        base_url = backend._backend_url()
        if not backend._is_configured():
            return _error(503, 'Brainbox AI is not configured yet. Ask your administrator to finish the setup '
                               'in Settings > Brainbox AI.')

        identity = {'user_id': 'odoo:%s:%s' % (request.db, user.id), 'user_name': user.name or '',
                    'user_role': backend._user_role(user)}
        tenant = backend._tenant()
        if tenant:
            identity['tenant_id'] = tenant

        headers = {'Accept': 'text/event-stream' if kind == 'stream' else 'application/json'}
        api_key = backend._api_key()
        if api_key:
            headers['Authorization'] = 'Bearer %s' % api_key

        params = None
        if httpreq.method == 'GET' and kind != 'none':
            params = {k: v for k, v in httpreq.args.items() if k not in IDENTITY_FIELDS}
            params['user_id'] = identity['user_id']
            if tenant:
                params['tenant_id'] = tenant

        options = {'params': params, 'headers': headers, 'timeout': timeout}
        if httpreq.method == 'POST' and kind in ('json', 'stream'):
            raw = httpreq.get_data()
            if len(raw) > MAX_JSON_BODY:
                return _error(413, 'The request is too large.')
            try:
                body = json.loads(raw or b'{}')
            except ValueError:
                return _error(400, 'Invalid JSON body.')
            if not isinstance(body, dict):
                return _error(400, 'Invalid JSON body.')
            for key in IDENTITY_FIELDS:
                body.pop(key, None)
            body.update(identity)
            options['json'] = body
        elif kind == 'multipart':
            upload = httpreq.files.get(file_field)
            if not upload or not upload.filename:
                return _error(400, 'No file received.')
            content = upload.read(MAX_UPLOAD_SIZE + 1)
            if len(content) > MAX_UPLOAD_SIZE:
                return _error(413, 'That file is too large. The maximum size is 10 MB.')
            data = dict(identity)
            session_id = (httpreq.form.get('session_id') or '').strip()
            if session_id:
                if not SESSION_ID_RE.match(session_id):
                    return _error(400, 'Invalid session id.')
                data['session_id'] = session_id
            options['data'] = data
            options['files'] = {file_field: (upload.filename, content, upload.mimetype or 'application/octet-stream')}

        url = '%s/%s' % (base_url, subpath)
        try:
            response = requests.request(httpreq.method, url, stream=(kind == 'stream'), **options)
        except requests.exceptions.Timeout:
            return _error(504, 'The Brainbox AI server took too long to respond. Please try again.')
        except requests.exceptions.RequestException as e:
            _logger.warning('Brainbox AI proxy: cannot reach backend (%s)', e.__class__.__name__)
            return _error(502, UNREACHABLE)

        if kind == 'stream':
            ctype = response.headers.get('Content-Type', '')
            if response.status_code == 200 and ctype.startswith('text/event-stream'):
                return _sse_response(response)
            if response.status_code in (404, 405) and not ctype.startswith('application/json'):
                # e.g. an HTML 404 from a reverse proxy: tell the SDK the route is missing so it falls back
                response.close()
                return _error(response.status_code, 'Not found.')

        content = response.content or b''
        try:
            json.loads(content or b'null')
        except ValueError:
            _logger.info('Brainbox AI proxy: non-JSON answer (HTTP %s) for %s', response.status_code, subpath)
            status = response.status_code if response.status_code >= 400 else 502
            return _error(status, 'The Brainbox AI server returned an invalid response.')
        return request.make_response(
            content,
            headers=[('Content-Type', 'application/json'), ('Cache-Control', 'no-store')],
            status=response.status_code,
        )
