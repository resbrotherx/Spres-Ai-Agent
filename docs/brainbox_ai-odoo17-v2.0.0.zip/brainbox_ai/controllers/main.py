# -*- coding: utf-8 -*-
"""Non-secret configuration and branding assets for the web SDK glue."""
import base64

from odoo import http
from odoo.http import request


class BrainboxAIController(http.Controller):

    @http.route('/brainbox_ai/config', type='json', auth='user')
    def config(self):
        """Settings mapped to Brainbox.init() options by static/src/js/brainbox_service.js."""
        return dict(request.env['brainbox.ai.backend'].get_public_config(), ok=True)

    @http.route('/brainbox_ai/logo', type='http', auth='user', methods=['GET'])
    def logo(self, **kw):
        logo = request.env['ir.config_parameter'].sudo().get_param('brainbox_ai.logo')
        if not logo:
            return request.not_found()
        try:
            content = base64.b64decode(logo)
        except Exception:
            return request.not_found()
        mimetype = 'image/png'
        if content[:3] == b'\xff\xd8\xff':
            mimetype = 'image/jpeg'
        elif content[:4] == b'GIF8':
            mimetype = 'image/gif'
        elif content[:4] == b'RIFF' and content[8:12] == b'WEBP':
            mimetype = 'image/webp'
        elif content.lstrip()[:5] in (b'<?xml', b'<svg ') or b'<svg' in content[:200]:
            # served as an image only; the CSP header prevents script execution
            mimetype = 'image/svg+xml'
        headers = [
            ('Content-Type', mimetype),
            ('Cache-Control', 'private, max-age=604800'),
            ('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'"),
            ('X-Content-Type-Options', 'nosniff'),
        ]
        return request.make_response(content, headers)
